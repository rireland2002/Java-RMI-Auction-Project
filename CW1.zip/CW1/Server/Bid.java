public class Bid
{
    int price;
    int itemID;
    User user;
}