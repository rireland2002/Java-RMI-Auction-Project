public class Bid implements java.io.Serializable
{
    int price;
    int itemID;
    User user;
}