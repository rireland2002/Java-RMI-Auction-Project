import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.ArrayList;
import java.util.Base64;

public class Server implements Auction
{   

    ArrayList<User> Users = new ArrayList<User>();
    ArrayList<Bid> Bids = new ArrayList<Bid>();
    ArrayList<AuctionItem> auctionItems = new ArrayList<AuctionItem>();
    Semaphore semaphore = new Semaphore(1);
    PrivateKey servPrivKey;
    PublicKey servPubKey;
    Integer auctionID;

    public Server()
    {
        super();
        try 
        {
            KeyPair keys = generateKeys();
            this.servPubKey = keys.getPublic();
            this.servPrivKey = keys.getPrivate();
            this.storePublicKey(servPubKey, "../keys/serverKey.pub");
            this.auctionID = 0;  
        } 
        catch (Exception e) 
        {
        }
    }

    public boolean verify(int userID, String token)
    {
        for(User currentUser : Users)
        {
            if(currentUser.UserID == userID)
            {
                if(currentUser.tokenState.equals(token) && currentUser.tokenTime > System.currentTimeMillis())
                {
                    currentUser.tokenState = "Used";
                    return true;
                }
            } 
        }
        return false;
    }
    
    public static KeyPair generateKeys()
    {
        try
        {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048);
            KeyPair keys = keyGen.generateKeyPair();
            return keys;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
    
    public Integer register(String email, PublicKey pubKey) throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        for(User currentUser : Users)
        {
            if(currentUser.email.equals(email))
            {
                semaphore.release();
                return null;
            }
        }
        Random random = new Random();
        int i = (Users.size()+1);
        String challengeWord = random.ints(97,122+1).limit(10).collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString();         
        try
        {
            User e = new User(i, pubKey, email, challengeWord);
            Users.add(e);
            semaphore.release();
            return i;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            semaphore.release();
            return null;
        }
    }

    public AuctionItem getSpec(int userID, int itemID, String token)throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        AuctionItem x = new AuctionItem();
        if(verify(userID, token) == true)
        {
            for(AuctionItem currentItem : auctionItems)
            {
                if(currentItem.itemID == itemID)
                {
                    x = currentItem;
                }
            }
        }
        else
        {
            semaphore.release();
            return null;
        }
        semaphore.release();
        return x;
    }
    
    public Integer newAuction(int userID, AuctionSaleItem item, String token) throws RemoteException
    {
        
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        if(verify(userID, token) == true)
        {
            for(User currentUser: Users)
            {
                if(currentUser.UserID == userID)
                {
                    Bid bid = new Bid();
                    bid.itemID = auctionID + 1;
                    bid.price = item.reservePrice;
                    bid.user = currentUser; 
                }
            }
            AuctionItem newItem = new AuctionItem();
            newItem.itemID = auctionID + 1;
            auctionID = auctionID +1;
            newItem.name = item.name;
            newItem.description = item.description;
            newItem.highestBid = item.reservePrice;
            auctionItems.add(newItem);
            for(User currentUser : Users)
            {
                if(currentUser.UserID == userID)
                {
                    System.out.println(auctionID);
                    currentUser.registerItem(auctionID);
                } 
            }
        }
        else
        {
            semaphore.release();
            return null;
        }
        semaphore.release();
        return auctionID;
    }   

    public AuctionItem[] listItems(int userID, String token) throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e){}
        AuctionItem[] x = new AuctionItem[auctionItems.size()];
        if(verify(userID, token) == true)
        { 
            auctionItems.toArray(x);
        }
        else
        {
            semaphore.release();
            return null;
        }
        semaphore.release();
        return x;
    }

    public AuctionResult closeAuction(int userID, int itemID, String token) throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        AuctionResult winAuction = new AuctionResult();
        if(verify(userID, token) == true)
        {
            for(User currentUser : Users)
            {
                if(currentUser.UserID == userID)
                {
                    for(Integer storedID : currentUser.registeredItems)
                    {
                        if(storedID == itemID)
                        {
                            for(AuctionItem removItem : auctionItems)
                            {
                                if(removItem.itemID == itemID)
                                {
                                    for(Bid finalBid : Bids)
                                    {
                                        if(finalBid.price == removItem.highestBid)
                                        {
                                            winAuction.winningEmail = finalBid.user.email;
                                            winAuction.winningPrice = finalBid.price;
                                            auctionItems.remove(removItem);
                                            semaphore.release();
                                            return winAuction;
                                        }
                                    }
                                }
                            }
                        }
                    }  
                }
            }
        }
        else
        {
            semaphore.release();
            return null;
        }
        semaphore.release();
        return winAuction;
    }
    
    public boolean bid(int userID, int itemID, int price, String token) throws RemoteException// bid will be unique, bid will equal highest bid at end so dont need to remove
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {
            
        }
        Bid newBid = new Bid();
        if(verify(userID, token) == true)
        {
            for(User currentUser: Users)
            {
               if(currentUser.UserID == userID)
               {
                   for(AuctionItem bidItem:auctionItems)
                   {
                       if(bidItem.itemID == itemID)
                       {
                           if(price > bidItem.highestBid)
                           {
                               bidItem.highestBid = price;
                               newBid.itemID = itemID;
                               newBid.price = price;
                               newBid.user = currentUser;
                               Bids.add(newBid);
                           }
                           else
                           {
                                semaphore.release();
                                return false; 
                           }
                       }
                   }
               }
            }
        }
        else
        {
            semaphore.release();
            return false;
        }
        semaphore.release();
        return true;
    }

    public ChallengeInfo challenge(int userID, String clientChallenge) throws RemoteException//Create a String, encyrpting using the public key of the client and the private key of the server, then decrypting on the client side using server public key and user private key
    {
        try
        {
            String data = clientChallenge;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashdata = md.digest(data.getBytes(StandardCharsets.UTF_8));
            Signature serverSign = Signature.getInstance("SHA256withRSA");
            serverSign.initSign(servPrivKey);
            serverSign.update(hashdata);
            byte[] serverSignedData = serverSign.sign();
            ChallengeInfo servInfo = new ChallengeInfo();
            servInfo.response = serverSignedData;
            Random random = new Random();
            servInfo.clientChallenge = random.ints(97,122+1).limit(10).collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
            for(User currentUser : Users)
            {
                if(currentUser.UserID == userID)
                {
                    currentUser.challengedString = servInfo.clientChallenge;
                }
            }
            return servInfo;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }        
    }

    public TokenInfo authenticate(int userID, byte signature[]) throws RemoteException
    {

        TokenInfo token = new TokenInfo();
        for(User currentUser : Users)
        {
            if(currentUser.UserID == userID)
            {
                try
                {
                    Random random = new Random();
                    Signature signer = Signature.getInstance("SHA256withRSA");
                    String clientWord = getChallengeWord(userID);
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    byte[] hashdata = md.digest(clientWord.getBytes(StandardCharsets.UTF_8));
                    signer.initVerify(currentUser.clientPubKey);
                    signer.update(hashdata);
                    boolean isValid = signer.verify(signature);
                    if(isValid == true)
                    {
                        token.expiryTime = System.currentTimeMillis()+10000;
                        token.token = random.ints(97,122+1).limit(10).collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString();;
                        currentUser.tokenTime = token.expiryTime;
                        currentUser.tokenState = token.token;
                        //if (expirationTime != null && System.currentTimeMillis() < expirationTime) 
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                    return null;
                }
            }
        }
        return token;
    }

    public String getChallengeWord(int userID)
    {
        String x = "";
        for(User currentUser : Users)
        {
            if(currentUser.UserID == userID)
            {
               x = currentUser.challengedString; 
            }
        }
        return x;
    }

    public void storePublicKey(PublicKey publicKey, String filePath) throws Exception 
    {
        // Convert the public key to a byte array
        byte[] publicKeyBytes = publicKey.getEncoded();
        // Encode the public key bytes as Base64
        String publicKeyBase64 = Base64.getEncoder().encodeToString(publicKeyBytes);
        // Write the Base64 encoded public key to a file
        try (FileOutputStream fos = new FileOutputStream(filePath)) 
        {
            fos.write(publicKeyBase64.getBytes());
        }
    }



    public static void main(String[] args) 
    {
        try 
        {
            Server s = new Server();
            String name = "Auction";
            Auction stub = (Auction) UnicastRemoteObject.exportObject(s, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind(name, stub);
            System.out.println("Auction ready");
        } 
        catch (Exception e) 
        {
            System.err.println("Exception:");
            e.printStackTrace();
        }
    }
}