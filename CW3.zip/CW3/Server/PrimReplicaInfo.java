import java.util.ArrayList;

public class PrimReplicaInfo implements java.io.Serializable
{
    ArrayList<User> Users = new ArrayList<User>();
    ArrayList<Bid> Bids = new ArrayList<Bid>();
    ArrayList<AuctionItem> auctionItems = new ArrayList<AuctionItem>();
    Integer auctionID;
    Integer userID;

    public PrimReplicaInfo(ArrayList<User> Users, ArrayList<Bid> Bids, ArrayList<AuctionItem> auctionItems, Integer auctionID, Integer userID) {
        this.Users = Users;
        this.Bids = Bids;
        this.auctionItems = auctionItems;
        this.auctionID = auctionID;
        this.userID = userID;
    }
}
    
