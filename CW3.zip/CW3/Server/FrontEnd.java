import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.security.*;
import java.util.ArrayList;
import java.util.Arrays;


public class FrontEnd implements Auction
{   
    public FrontEnd()
    {
        super();
        try 
        {
        } 
        catch (Exception e) 
        {
        }
    }
    
    public Integer register(String email, PublicKey pubKey) throws RemoteException//get prim replica
    {
        ReplicaInterface primReplica = this.getPrimReplica();
        if(primReplica == null)
        {
            System.out.println("No server found, please register new replicas");
            return null;
        }
        else
        {
            System.out.println(primReplica.returnReplicaID());
            Integer i = primReplica.register(email, pubKey);
            if(i == null)
            {
                System.out.println("User already registered");
                return null;
            }
            else
            {
                System.out.println("User ID is "+ i);
                return i;
            }
        }
    }

    public AuctionItem getSpec(int userID, int itemID, String token)throws RemoteException
    {
        ReplicaInterface primReplica = getPrimReplica();
        if(primReplica == null)
        {
            System.out.println("No server found, please register new replicas");
            return null;
        }
        else
        {
            AuctionItem newItem = primReplica.getSpec(userID, itemID, token);
            if(newItem == null)
            {
                System.out.println("Item could not be found, please try again.");
                return null;
            }
            else
            {
                return newItem;
            }
        }
    }
    
    public Integer newAuction(int userID, AuctionSaleItem item, String token) throws RemoteException
    {
        ReplicaInterface primReplica = getPrimReplica();
        if(primReplica == null)
        {
            System.out.println("No server found, please register new replicas");
            return null;
        }
        else
        {
            Integer i = primReplica.newAuction(userID, item, token);
            if(i == null)
            {
                System.out.println("Item could not be listed, please try again.");
            }
            System.out.println("The auction item ID is:"+i);
            return i;    
        }
    }   

    public AuctionItem[] listItems(int userID, String token) throws RemoteException
    {
        ReplicaInterface primReplica = getPrimReplica();
        if(primReplica == null)
        {
            System.out.println("No server found, please register new replicas");
            return null;
        }
        else
        {
            AuctionItem[] itemList = primReplica.listItems(userID, token);
            if(itemList == null)
            {
                System.out.println("No items to list");
                return null;
            }
            else
            {
                return itemList;
            }
        }
    }

    public AuctionResult closeAuction(int userID, int itemID, String token) throws RemoteException
    {
        ReplicaInterface primReplica = getPrimReplica();
        if(primReplica == null)
        {
            System.out.println("No server found, please register new replicas");
            return null;
        }
        else
        {
            AuctionResult replicaResult = primReplica.closeAuction(userID, itemID, token);
            if(replicaResult == null)
            {
                return null;
            }
            else
            {
                return replicaResult;
            }
        }
    }
    
    public boolean bid(int userID, int itemID, int price, String token) throws RemoteException
    {
        ReplicaInterface primReplica = getPrimReplica();
        if(primReplica == null)
        {
            System.out.println("No server found, please register new replicas");
            return false;
        }
        else
        {
            boolean replicaBid = primReplica.bid(userID, itemID, price, token);
            if(replicaBid == false)
            {
                return false;
            }
            else
            {
                return replicaBid;
            }
        }
    }

    public ChallengeInfo challenge(int userID, String clientChallenge) throws RemoteException
    {
       return null;
    }
            
    public TokenInfo authenticate(int userID, byte signature[]) throws RemoteException
    {
        return null;
    }

    public int getPrimaryReplicaID() throws RemoteException
    {
        try
        {
            Registry registry = LocateRegistry.getRegistry("localhost");
            String[] registryNames = registry.list();
            ArrayList<String> registryList = new ArrayList<>(Arrays.asList(registryNames));
            registryList.remove("FrontEnd");
            for(String currentRegistry:registryList)
            {
                try
                {
                    ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                    repInf.returnReplicaID();
                }
                catch(Exception e)
                {
                    registry.unbind(currentRegistry);
                }
            }
            for(String currentRegistry:registryList)
            {
                ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                if(repInf.isPrimary() == true)
                {
                    System.out.println(currentRegistry);
                    return repInf.returnReplicaID();
                }
                else
                {
                    ReplicaInterface repInf2 =repInf.getPrimaryReplica();
                    return repInf2.returnReplicaID();
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }
        return 0;
    }

    public ReplicaInterface getPrimReplica()
    {
        try
        {
            Registry registry = LocateRegistry.getRegistry("localhost");
            String[] registryNames = registry.list();
            ArrayList<String> registryList = new ArrayList<>(Arrays.asList(registryNames));
            registryList.remove("FrontEnd");
            for(String currentRegistry:registryList)
            {
                try
                {
                    ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                    repInf.returnReplicaID();
                }
                catch(Exception e)
                {
                    registry.unbind(currentRegistry);
                }
            }
            for(String currentRegistry:registryList)
            {
                System.out.println(currentRegistry);
                ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                if(repInf.isPrimary() == true)
                {
                    System.out.println("Current primary is:"+currentRegistry);
                    return repInf;
                }   
            }
            registryNames = registryList.toArray(new String[0]);
            ReplicaInterface repInf = (ReplicaInterface) registry.lookup(registryNames[0]);
            ReplicaInterface primRep = repInf.getPrimaryReplica();
            return primRep;   
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args)
    {
        try 
        {
            Registry registry = LocateRegistry.getRegistry("localhost");
            FrontEnd s = new FrontEnd();
            String name = "FrontEnd";
            Auction stub = (Auction) UnicastRemoteObject.exportObject(s, 0);
            registry.rebind(name, stub);
            System.out.println("FrontEnd ready");
        } 
        catch (Exception e) 
        {
            System.err.println("Exception:");
            e.printStackTrace();
        }
    }
}