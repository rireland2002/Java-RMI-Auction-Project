import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.io.FileOutputStream;
import java.security.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;

public class Replica implements ReplicaInterface 
{   

    ArrayList<User> Users = new ArrayList<User>();
    ArrayList<Bid> Bids = new ArrayList<Bid>();
    ArrayList<AuctionItem> auctionItems = new ArrayList<AuctionItem>();
    Semaphore semaphore = new Semaphore(1);
    Integer auctionID;
    Integer replicaID;
    Integer updateCount;
    Integer userID;
    Boolean primReplica;
    

    public Replica(int ID)
    {
        super();
        try 
        {
            this.auctionID = 0;
            this.replicaID = ID;  
            this.updateCount = 1;
            this.primReplica = false;
            this.userID = 1;
        } 
        catch (Exception e) 
        {
        }
    }
    
    public Integer register(String email, PublicKey pubKey) throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        for(User currentUser : Users)
        {
            if(currentUser.email.equals(email))
            {
                semaphore.release();
                return null;
            }
        }
        Random random = new Random();
        int i = this.userID;
        this.userID++;
        String challengeWord = random.ints(97,122+1).limit(10).collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString();         
        try
        {
            User e = new User(i, pubKey, email, challengeWord);
            Users.add(e);
            this.uploadState();
            semaphore.release();
            return i;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            semaphore.release();
            return null;
        }
    }

    public AuctionItem getSpec(int userID, int itemID, String token)throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        AuctionItem x = new AuctionItem();
      
        for(AuctionItem currentItem : auctionItems)
        {
            if(currentItem.itemID == itemID)
            {
                x = currentItem;
                semaphore.release();
                return x;
            }
        }
        semaphore.release();
        return null;    
    }
    
    public Integer newAuction(int userID, AuctionSaleItem item, String token) throws RemoteException
    {
        
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        for(User currentUser: Users)
        {
            if(currentUser.UserID == userID)
            {
                Bid bid = new Bid();
                bid.itemID = auctionID + 1;
                bid.price = item.reservePrice;
                bid.user = currentUser; 
            }
        }
        AuctionItem newItem = new AuctionItem();
        newItem.itemID = auctionID + 1;
        auctionID = auctionID +1;
        newItem.name = item.name;
        newItem.description = item.description;
        newItem.highestBid = item.reservePrice;
        auctionItems.add(newItem);
            for(User currentUser : Users)
            {
                if(currentUser.UserID == userID)
                {
                    System.out.println(auctionID);
                    currentUser.registerItem(auctionID);
                    this.uploadState();
                    semaphore.release();
                    return auctionID;
                } 
            }
            semaphore.release();
            return null;
        }
    
    public AuctionItem[] listItems(int userID, String token) throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e){}
        AuctionItem[] x = new AuctionItem[auctionItems.size()];
        if(x.length == 0)
        {
            semaphore.release();
            return null;
        }
        else
        {
            auctionItems.toArray(x);
            semaphore.release();
            return x;
        }
        
    }

    public AuctionResult closeAuction(int userID, int itemID, String token) throws RemoteException
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {

        }
        AuctionResult winAuction = new AuctionResult();
        for(User currentUser : Users)
        {
            if(currentUser.UserID == userID)
            {
                for(Integer storedID : currentUser.registeredItems)
                {
                    if(storedID == itemID)
                    {
                        for(AuctionItem removItem : auctionItems)
                        {
                            if(removItem.itemID == itemID)
                            {
                                for(Bid finalBid : Bids)
                                {
                                    if(finalBid.price == removItem.highestBid)
                                    {
                                        winAuction.winningEmail = finalBid.user.email;
                                        winAuction.winningPrice = finalBid.price;
                                        auctionItems.remove(removItem);
                                        this.uploadState();
                                        semaphore.release();
                                        return winAuction;
                                    }
                                }
                            }
                            else
                            {
                                semaphore.release();
                                return null;
                            }
                        }
                    }
                    else
                    {
                        semaphore.release();
                        return null;
                    }
                }  
            }
            else
            {
                semaphore.release();
                return null;
            }
        }
        this.uploadState();
        semaphore.release();
        return winAuction;
    }
    
    public boolean bid(int userID, int itemID, int price, String token) throws RemoteException// bid will be unique, bid will equal highest bid at end so dont need to remove
    {
        try
        {
            semaphore.acquire();
        }
        catch(Exception e)
        {
            
        }
        Bid newBid = new Bid();
        for(User currentUser: Users)
        {
            if(currentUser.UserID == userID)
            {
                for(AuctionItem bidItem:auctionItems)
                {
                    if(bidItem.itemID == itemID)
                    {
                        if(price > bidItem.highestBid)
                        {
                            bidItem.highestBid = price;
                            newBid.itemID = itemID;
                            newBid.price = price;
                            newBid.user = currentUser;
                            Bids.add(newBid);
                            this.uploadState();
                            semaphore.release();
                            return true;
                        }
                       else
                       {
                            semaphore.release();
                            return false; 
                       }
                   }
                }
            }
        }
        semaphore.release();
        return false;
    }

    public ChallengeInfo challenge(int userID, String clientChallenge) throws RemoteException//Create a String, encyrpting using the public key of the client and the private key of the server, then decrypting on the client side using server public key and user private key
    {
        return null;      
    }

    public TokenInfo authenticate(int userID, byte signature[]) throws RemoteException
    {
        return null;
    }

    public void storePublicKey(PublicKey publicKey, String filePath) throws Exception 
    {
        // Convert the public key to a byte array
        byte[] publicKeyBytes = publicKey.getEncoded();
        // Encode the public key bytes as Base64
        String publicKeyBase64 = Base64.getEncoder().encodeToString(publicKeyBytes);
        // Write the Base64 encoded public key to a file
        try (FileOutputStream fos = new FileOutputStream(filePath)) 
        {
            fos.write(publicKeyBase64.getBytes());
        }
    }

    public boolean isPrimary()
    {
        return this.primReplica;
    }

    public void setPrimary()
    {
        this.primReplica = true;
    }

    public int returnUpdateCount()
    {
        return updateCount;
    }

    public PrimReplicaInfo starterInfo()
    {
        PrimReplicaInfo primInfo = new PrimReplicaInfo(Users, Bids, auctionItems, auctionID, userID);
        return primInfo;
    }

    public void downloadState(ArrayList<User> Users, ArrayList<Bid> Bids, ArrayList<AuctionItem> auctionItems, Integer auctionID, Integer userID)
    {
        this.Users = Users;
        this.Bids = Bids;
        this.auctionItems = auctionItems;
        this.auctionID = auctionID;
        this.userID = userID;
        this.updateCount = this.updateCount+1;
    }

    public void uploadState()
    {
        try
        {
            this.updateCount = this.updateCount+1;
            Registry registry = LocateRegistry.getRegistry("localhost");
            String[] registryNames = registry.list();
            ArrayList<String> registryList = new ArrayList<>(Arrays.asList(registryNames));
            registryList.remove("FrontEnd");
            registryList.remove("Replica"+this.replicaID);
            if(registryList.isEmpty())
            {
               System.out.println("No replica to update"); 
            }
            else
            {
                for(String currentRegistry : registryList)
                {
                   ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                   repInf.downloadState(Users, Bids, auctionItems, auctionID, userID); 
                }
            } 
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public int returnReplicaID()
    {
        return replicaID;
    }



    public ReplicaInterface electNewPrimary()
    {
        try
        {
            Integer currentNominee = this.replicaID;
            Integer highestUpdateCount = this.updateCount;
            Registry registry = LocateRegistry.getRegistry("localhost");
            String[] registryNames = registry.list();
            ArrayList<String> registryList = new ArrayList<>(Arrays.asList(registryNames));
            registryList.remove("FrontEnd");
            if(registryList.size() == 1)
            {
               this.setPrimary();
            }
            else
            {
                for(String currentRegistry:registryList)
                {
                    try
                    {
                        ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                        repInf.returnReplicaID();
                    }
                    catch(Exception e)
                    {
                        registry.unbind(currentRegistry);
                    }
                }
                for(String currentRegistry : registryList)
                {
                    ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                        if(repInf.isPrimary() == true)
                        {
                            System.out.println("Primary still active ID is Replica"+repInf.returnReplicaID());
                            return repInf;
                        }
                }
                for(String currentRegistry : registryList)
                {
                    ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                    if(repInf.returnUpdateCount()>=highestUpdateCount)
                    {
                        currentNominee = repInf.returnReplicaID();
                        highestUpdateCount = repInf.returnUpdateCount();
                    }
                }
                ReplicaInterface repInf = (ReplicaInterface) registry.lookup("Replica"+currentNominee);
                repInf.setPrimary();
                System.out.println("New primary replica is Replica"+currentNominee);
                return repInf;
            }
            return this;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public ReplicaInterface getPrimaryReplica()
    {
        try
        {
            Registry registry = LocateRegistry.getRegistry("localhost");
            String[] registryNames = registry.list();
            ArrayList<String> registryList = new ArrayList<>(Arrays.asList(registryNames));
            registryList.remove("FrontEnd");
            if(registryList.isEmpty())
            {
               System.out.println("Registry empty, no replicas to copy from");
               return null; 
            }
            else
            {
                for(String currentRegistry:registryList)
                {
                    try
                    {
                        ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                        repInf.returnReplicaID();
                    }
                    catch(Exception e)
                    {
                        registry.unbind(currentRegistry);
                    }
                }
                for(String currentRegistry : registryList)
                {
                    ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                    if(repInf.isPrimary() == true)
                    {
                        return repInf;
                    }
                }
                System.out.println("No registered primary, finding new replica");
                ReplicaInterface primID = electNewPrimary();
                return primID;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("No primary can be elected or found");
            return null;
        }
    }

    public int getPrimaryReplicaID() throws RemoteException
    {
        ReplicaInterface primReplica = getPrimaryReplica();
        int ID = primReplica.returnReplicaID();
        return ID;
    }

    public static void main(String[] args)
    {
        try 
        {
            String ID = args[0];
            int numID = Integer.parseInt(args[0]);
            Replica rs = new Replica(numID);
            String name = "Replica"+ID;
            ReplicaInterface stub = (ReplicaInterface) UnicastRemoteObject.exportObject(rs, 0);
            Registry registry = LocateRegistry.getRegistry("localhost");
            String[] registryNames = registry.list();
            ArrayList<String> registryList = new ArrayList<>(Arrays.asList(registryNames));
            registryList.remove("FrontEnd");
            if(registryList.contains("Replica"+ID))
            {
                System.out.println("This replica is already registered, unbinding...");
                registry.unbind("Replica"+ID);
                ReplicaInterface copyPrim = rs.getPrimaryReplica();
                if(copyPrim == null)
                {
                    System.out.println("No replica to copy from");  
                }
                else
                {
                    PrimReplicaInfo copInf = copyPrim.starterInfo();
                    rs.Users = copInf.Users;
                    rs.Bids = copInf.Bids; 
                    rs.auctionItems = copInf.auctionItems;
                    rs.auctionID = copInf.auctionID;
                    rs.userID = copInf.userID;
                    System.out.println("Copied successfully");
                }
            }
            else
            {
                for(String currentRegistry:registryList)
                {
                    try
                    {
                        ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                        repInf.returnReplicaID();
                    }
                    catch(Exception e)
                    {
                        registry.unbind(currentRegistry);
                    }
                }
                for(String currentRegistry: registryList)
                {
                   
                    ReplicaInterface repInf = (ReplicaInterface) registry.lookup(currentRegistry);
                    if(repInf.isPrimary() == true)
                    {
                        PrimReplicaInfo copInf = repInf.starterInfo();
                        rs.Users = copInf.Users;
                        rs.Bids = copInf.Bids;
                        rs.auctionItems = copInf.auctionItems;
                        rs.auctionID = copInf.auctionID;
                        rs.userID = copInf.userID;
                        System.out.println("Copied successfully");
                    }
                }
            }
            registry.rebind(name, stub);
            System.out.println("Replica"+ID+" ready");
        } 
        catch (Exception e) 
        {
            System.err.println("Exception:");
            e.printStackTrace();
        }
    }
}




















