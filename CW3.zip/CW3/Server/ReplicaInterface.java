import java.rmi.Remote;
import java.rmi.RemoteException;
import java.security.PublicKey;
import java.util.ArrayList;

public interface ReplicaInterface extends Remote
{
    public AuctionItem getSpec(int userID, int itemID, String token) throws RemoteException;

    public Integer newAuction(int userID, AuctionSaleItem item, String token) throws
    RemoteException;

    public AuctionItem[] listItems(int userID, String token) throws RemoteException;

    public AuctionResult closeAuction(int userID, int itemID, String token) throws
    RemoteException;
    
    public boolean bid(int userID, int itemID, int price, String token) throws
    RemoteException;

    public Integer register(String email, PublicKey pubKey) throws RemoteException;
    
    public ChallengeInfo challenge(int userID, String clientChallenge) throws
    RemoteException;
    
    public TokenInfo authenticate(int userID, byte signature[]) throws RemoteException;

    public int getPrimaryReplicaID() throws RemoteException;

    public boolean isPrimary() throws RemoteException;

    public void downloadState(ArrayList<User> Users, ArrayList<Bid> Bids, ArrayList<AuctionItem> auctionItems, Integer auctionID, Integer userID) throws RemoteException;

    public void uploadState() throws RemoteException;

    public ReplicaInterface electNewPrimary() throws RemoteException;

    public int returnUpdateCount() throws RemoteException;

    public int returnReplicaID() throws RemoteException;
    
    public void setPrimary() throws RemoteException;

    public ReplicaInterface getPrimaryReplica() throws RemoteException;

    public PrimReplicaInfo starterInfo() throws RemoteException;

    public void storePublicKey(PublicKey publicKey, String filePath) throws Exception; 
}