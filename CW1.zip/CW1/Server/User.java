import java.security.*;
import java.util.ArrayList;

public class User
{
    int UserID;
    PublicKey clientPubKey;
    String email;
    String challengeString;
    String challengedString;
    TokenInfo token;
    Long tokenTime;
    String tokenState;
    ArrayList<Integer> registeredItems = new ArrayList<Integer>();

    public User(int UserID, PublicKey pubKey, String email, String chString)
    {
        this.UserID = UserID;
        this.clientPubKey = pubKey;
        this.email = email;
        this.challengeString = chString;
    }

    public int getID()
    {
        return UserID;
    }

    public String getChallengeWord()
    {
        return challengeString;
    }

    public void registerItem(Integer itemID)
    {
        registeredItems.add(itemID);
    }
}

